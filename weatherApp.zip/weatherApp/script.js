let myCity = "Oslo"
console.log(myCity)

let myKey = "2e7ab11015602d7d8c302c7e61e44627"
let myAPI =`https://api.openweathermap.org/data/2.5/weather?q=${myCity}&units=metric&appid=${myKey}`
let input = document.getElementById("searchField")
let inputButton = document.getElementById("searchButton")
fetch(myAPI)
 .then( response => response.json())
 .then(data => {
    console.log("Api virker")
 })

inputButton.addEventListener("click", getValue ());

input.onkeydown = function (e) {
    if (e.key === 'Enter') {
        getValue()
    }
    
}

function getValue() {
    console.log("klikk")
    let city = document.getElementById("searchField").value
    console.log(city)
}